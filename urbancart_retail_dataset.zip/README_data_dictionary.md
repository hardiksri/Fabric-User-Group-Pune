# UrbanCart Omnichannel Retail Dataset (2023-2025)

Synthetic Superstore-style retailer selling through 17 physical stores and 2 online stores across
6 countries (US, Canada, UK, Germany, Australia, India), via In-Store, Website, Mobile App and Marketplace.
All money in USD. Date keys are integers in YYYYMMDD format. Fiscal year starts in February (retail calendar).

## Tables

| Table | Grain | Primary key |
|---|---|---|
| dim_date | One row per day, 2018-2026, with retail_event (Black Friday, Cyber Monday, Holiday Rush...) | date_key |
| dim_customer | One row per customer | customer_id |
| dim_product | One row per SKU (Department > Category > Product) | product_id |
| dim_store | One row per store (Flagship, Standard, Express, Online) | store_id |
| dim_channel | In-Store, Website, Mobile App, Marketplace | channel_id |
| dim_ship_mode | In-Store Purchase, Standard, Express, Same-Day, Click & Collect | ship_mode_id |
| dim_promotion | One row per promotion campaign (PR000 = No Promotion) | promotion_id |
| fact_sales | One row per order line | order_line_id |
| fact_return | One row per returned order line | return_id |
| fact_inventory_monthly | Month-end stock for the top 120 SKUs in each physical store | snapshot_date_key + store_id + product_id |
| fact_sales_target | Monthly sales and gross-profit target per store and department | target_month_key + store_id + department |

## Relationships (child -> parent)

| Column | Parent |
|---|---|
| fact_sales.order_date_key | dim_date.date_key (active) |
| fact_sales.ship_date_key / delivery_date_key | dim_date.date_key (secondary) |
| fact_sales.customer_id / product_id / store_id / channel_id / ship_mode_id / promotion_id | matching dimension |
| fact_return.order_line_id | fact_sales.order_line_id |
| fact_return.return_date_key | dim_date.date_key |
| fact_return.customer_id / product_id / store_id / channel_id | matching dimension |
| fact_inventory_monthly.snapshot_date_key / store_id / product_id | matching dimension |
| fact_sales_target.target_month_key | dim_date.date_key (first day of month) |
| fact_sales_target.store_id | dim_store.store_id |
| fact_sales_target.department | dim_product.department (many-to-many; use a Department bridge or TREATAS) |
| dim_customer.home_store_id | dim_store.store_id |

## Key columns

**fact_sales**
- quantity, unit_price_usd, discount_pct (fraction: 0.2 = 20%)
- gross_sales_usd = quantity x unit price; discount_amount_usd; net_sales_usd = gross - discount
- cogs_usd, shipping_cost_usd, marketplace_fee_usd (15% of net on Marketplace)
- gross_profit_usd = net_sales - cogs - shipping - marketplace fee
- payment_method (incl. Buy Now Pay Later; UPI and Cash on Delivery in India)
- Online orders are booked to store S18 (US) or S19 (International), except Click & Collect, which is booked to the pickup store.

**fact_return**: return_reason, item_condition (Resellable, Open Box, Damaged / Defective), return_quantity,
refund_amount_usd, restocking_cost_usd, return_method (In-Store / Mail-In)

**fact_inventory_monthly** (semi-additive - never sum stock across months):
units_on_hand, units_received, units_sold, stockout_days, inventory_value_at_cost_usd, weeks_of_supply, is_below_reorder_point

**dim_customer**: segment (Consumer, Small Business, Corporate), market, loyalty membership and loyalty_tier
(Bronze-Platinum based on lifetime spend), signup channel, home store

## Stories built into the data
- Digital channels grow from ~44% of net sales (2023) to ~55% (2025); Mobile App gains while Website flattens.
- Marketplace has roughly half the gross margin of other channels because of its 15% fee.
- Black Friday, Cyber Monday and the Holiday Rush drive big spikes; Electronics peaks in Nov-Dec, Sports in Jan and summer.
- New stores open in Melbourne (Mar 2024), Mumbai (Jun 2024) and Bengaluru (Oct 2024), driving 2025 growth; India beats its targets.
- The UK misses its 2025 targets.
- Fashion has the highest return rate (mostly Wrong Size); online orders and deep-discount clearance items return far more often.
- Deep promotions (Doorbusters, Boxing Week Clearance) lift volume but crush margin.
- Electronics stock runs short in Nov-Dec, causing stockout days in peak season.
