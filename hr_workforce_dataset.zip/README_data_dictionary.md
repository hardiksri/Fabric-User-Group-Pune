# HR & Workforce Synthetic Dataset (2023-2025)

Synthetic HR data for a fictional ~1,000-1,150 person company across 10 departments and 9 locations
(US, Canada, UK, India). All money is in USD. Date keys are integers in YYYYMMDD format.
Fiscal year runs April to March (FY2025 = Apr 2024 - Mar 2025).

## Tables

| Table | Grain | Primary key |
|---|---|---|
| dim_date | One row per calendar day, 2012-2026 | date_key |
| dim_employee | One row per employee ever employed (current attributes) | employee_id |
| dim_department | One row per department | department_id |
| dim_job | One row per job (department x level L1-L6), with salary bands | job_id |
| dim_location | One row per office / remote location | location_id |
| fact_headcount_monthly | Month-end snapshot: one row per employee per month they were employed | snapshot_date_key + employee_id |
| fact_payroll | One row per employee per monthly pay period | pay_period_date_key + employee_id |
| fact_requisition | One row per job requisition (hiring funnel) | requisition_id |
| fact_termination | One row per employee exit (2023-2025) | employee_id |
| fact_performance_review | One row per employee per annual review (March) | employee_id + review_year |

## Relationships (fact -> dimension)

| Fact column | Dimension |
|---|---|
| fact_headcount_monthly.snapshot_date_key | dim_date.date_key |
| fact_payroll.pay_period_date_key | dim_date.date_key |
| fact_requisition.open_date_key | dim_date.date_key (active) |
| fact_requisition.filled_date_key | dim_date.date_key (secondary; null if not filled) |
| fact_termination.termination_date_key | dim_date.date_key |
| fact_performance_review.review_date_key | dim_date.date_key |
| *.employee_id / fact_requisition.hired_employee_id | dim_employee.employee_id |
| *.department_id | dim_department.department_id |
| *.job_id (also job_id_before / job_id_after) | dim_job.job_id |
| *.location_id | dim_location.location_id |
| dim_job.department_id | dim_department.department_id |
| dim_employee.manager_employee_id | dim_employee.employee_id (self-reference) |

Facts carry department_id, job_id and location_id as of that month / event, so promotions and
transfers are reported correctly over time. dim_employee holds only the latest values.

## Key columns

**fact_headcount_monthly** (semi-additive - never sum across months)
- is_active_end_of_month: TRUE if employed on the last day of the month. Headcount = count where TRUE.
- is_new_hire / is_termination: TRUE in the month the employee joined / left.
- fte: 1.0 full-time and contract, 0.5 part-time.
- annual_salary_usd, compa_ratio (salary / location-adjusted band midpoint), tenure_months, age, performance_rating.

**fact_payroll** (additive)
- base_pay_usd, overtime_hours, overtime_pay_usd, bonus_pay_usd, benefits_cost_usd
- gross_pay_usd = base + overtime + bonus
- total_compensation_cost_usd = gross + benefits
- Annual bonuses pay in March (L3+); Sales also gets a December commission bonus.

**fact_requisition** (hiring funnel)
- requisition_status: Filled, Open, Cancelled
- applicants > screened > interviews > offers_extended > offers_accepted
- days_to_fill, source (Referral, LinkedIn, Agency, etc.), recruitment_cost_usd, is_replacement (backfill vs new role)

**fact_termination**
- termination_type: Voluntary / Involuntary
- termination_reason, is_regrettable_loss (voluntary exit of a 4-5 rated employee)
- tenure_months_at_exit, performance_rating_at_exit, annual_salary_at_exit_usd

**fact_performance_review**
- performance_rating 1-5 with rating_label, merit_increase_pct, is_promoted
- salary_before_usd / salary_after_usd, engagement_score (1-5)

## Stories built into the data
- Annual attrition of roughly 14-18%; highest in Customer Support, Sales and Marketing.
- June 2024 restructuring wave in Marketing and Customer Support (involuntary spike).
- India delivery centers have higher attrition than other locations.
- Employees paid below band (compa ratio < 0.9) and with low engagement leave more often, mostly for Compensation or Manager Relationship.
- New joiners (< 1 year tenure) leave at higher rates.
- Agency hires cost far more per hire than referrals.
- Headcount grows ~18% over three years, with a hiring slowdown in 2024.
